# Wormy (a Nibbles clone)
# By Al Sweigart al@inventwithpython.com
# http://inventwithpython.com/pygame
# Released under a "Simplified BSD" license

#KRT 14/06/2012 modified Start Screen and Game Over screen to cope with mouse events
#KRT 14/06/2012 Added a non-busy wait to Game Over screen to reduce processor loading from near 100%

#
# Modified by Grant Clarke
# g.clarke@abertay.ac.uk
#
#execfile("chess.py") <- to launch

import random, pygame, sys
from pygame.locals import *

FPS = 15
WINDOWWIDTH = 640
WINDOWHEIGHT = 640
CELLSIZE= 80
ROW = 0
COL = 0
assert WINDOWWIDTH % CELLSIZE == 0, "Window width must be a multiple of cell size."
assert WINDOWHEIGHT % CELLSIZE == 0, "Window height must be a multiple of cell size."
CELLWIDTH = int(WINDOWWIDTH / CELLSIZE)
CELLHEIGHT = int(WINDOWHEIGHT / CELLSIZE)

#             R    G    B
WHITE     = (255, 255, 255)
BLACK     = (  0,   0,   0)
RED       = (255,   0,   0)
GREEN     = (  0, 255,   0)
DARKGREEN = (  0, 155,   0)
DARKGRAY  = ( 40,  40,  40)
BGCOLOR = BLACK
CURRENTCOLOUR = WHITE

class square:
	x = 0
	y = 0
	size = 80
	occupied = False
	colour = (  0,   0,   0)
	selected = False
	def setPositionX(self, newX):#Sets x position
		self.x = newX
	def setPositionY(self, newY):#Sets y position
		self.y = newY
	def draw(self):#Draws the square
		pygame.draw.rect(DISPLAYSURF, self.colour, (self.x, self.y, self.size, self.size))
	def setColour(self, newColour):#Sets the square's colour
		self.colour = newColour
	def getColour(self):#Returns the square's colour
		return self.colour
	def setSelected(self, newState):#Sets square to selected
		self.selected = newState
	def getSelected(self):#Return if square has been selected
		return self.selected
	def setOccupied(self, newState):#Set square to occupied
		self.occupied = newState
	def getPositionX(self): #Return x position
		return self.x
	def getPositionY(self): #Return y position
		return self.y
	def getSize(self): #Return size
		return self.size

UP = 'up'
DOWN = 'down'
LEFT = 'left'
RIGHT = 'right'
mouseX = 0
mouseY = 0
SELECTED = False
gridSquares = []
for i in range(64):
	gridSquares.append(square())
#
#
#
def main():
    init()
    showStartScreen()
    while True:
        runGame()
        showGameOverScreen()

def init():
    global FPSCLOCK, DISPLAYSURF, BASICFONT

    pygame.init()
    FPSCLOCK = pygame.time.Clock()
    DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
    BASICFONT = pygame.font.Font('freesansbold.ttf', 18)
    pygame.display.set_caption('Chess')
    
def runGame():
    game_init()    
    while True: # main game loop
        game_over = game_update()
        game_render()
        if game_over == True:
            return # game over, stop running the game


def game_init():
    global ROW, COL, SQUARESIZE, CURRENTCOLOUR
    for i in gridSquares:
	i.setPositionY(COL * CELLSIZE)
	i.setPositionX(ROW * CELLSIZE)
	i.setColour(CURRENTCOLOUR)
	if CURRENTCOLOUR == WHITE:
		CURRENTCOLOUR = BLACK
	else:
		CURRENTCOLOUR = WHITE
	ROW = ROW + 1
	if ROW == 8:
		ROW = 0
		COL = COL + 1
		if CURRENTCOLOUR == BLACK:
			CURRENTCOLOUR = WHITE
		else:
			CURRENTCOLOUR = BLACK

def game_update():
    checkMouse()
    
    # game is not over, return False
    return False

def game_render():
    DISPLAYSURF.fill(BGCOLOR)
    for i in gridSquares:
		i.draw()
		if i.getSelected() == True:
			pygame.draw.rect(DISPLAYSURF, RED, (i.getPositionX(), i.getPositionY(), i.getSize(), i.getSize()), 5)
    pygame.display.update()
    FPSCLOCK.tick(FPS)

def drawPressKeyMsg():
    pressKeySurf = BASICFONT.render('Press a key to play.', True, DARKGRAY)
    pressKeyRect = pressKeySurf.get_rect()
    pressKeyRect.topleft = (WINDOWWIDTH - 200, WINDOWHEIGHT - 30)
    DISPLAYSURF.blit(pressKeySurf, pressKeyRect)

# KRT 14/06/2012 rewrite event detection to deal with mouse use
def checkForKeyPress():
    for event in pygame.event.get():
        if event.type == QUIT:      #event is quit 
            terminate()
        elif event.type == KEYDOWN:
            if event.key == K_ESCAPE:   #event is escape key
                terminate()
            else:
                return event.key   #key found return with it
    # no quit or key events in queue so return None    
    return None
def checkMouse():#Handles the mouse presses and select
    global mouseX, mouseY, SELECTED
    for event in pygame.event.get():
	if event.type == MOUSEBUTTONDOWN and event.button == 1:#Checks for left click
		mouseX, mouseY = pygame.mouse.get_pos()
		for i in gridSquares:#For each square
			if mouseX >= i.getPositionX()  and mouseX  < (i.getPositionX() + i.getSize()):
				if mouseY  >= i.getPositionY() and mouseY  <= (i.getPositionY() + i.getSize()):
					if SELECTED == False:
						i.setSelected(True)
						SELECTED = True
	if event.type == MOUSEBUTTONDOWN and event.button == 3:#Checks for right click
		for i in gridSquares:
			if i.getSelected() == True:
				i.setSelected(False)
				SELECTED = False
    
def showStartScreen():
    titleFont = pygame.font.Font('freesansbold.ttf', 100)
    titleSurf1 = titleFont.render('Chess!', True, WHITE, DARKGREEN)
    titleSurf2 = titleFont.render('Chess!', True, GREEN)

    degrees1 = 0
    degrees2 = 0
    
#KRT 14/06/2012 rewrite event detection to deal with mouse use
    pygame.event.get()  #clear out event queue
    
    while True:
        DISPLAYSURF.fill(BGCOLOR)
        rotatedSurf1 = pygame.transform.rotate(titleSurf1, degrees1)
        rotatedRect1 = rotatedSurf1.get_rect()
        rotatedRect1.center = (WINDOWWIDTH / 2, WINDOWHEIGHT / 2)
        DISPLAYSURF.blit(rotatedSurf1, rotatedRect1)

        rotatedSurf2 = pygame.transform.rotate(titleSurf2, degrees2)
        rotatedRect2 = rotatedSurf2.get_rect()
        rotatedRect2.center = (WINDOWWIDTH / 2, WINDOWHEIGHT / 2)
        DISPLAYSURF.blit(rotatedSurf2, rotatedRect2)

        drawPressKeyMsg()
#KRT 14/06/2012 rewrite event detection to deal with mouse use
        if checkForKeyPress():
            return
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        degrees1 += 3 # rotate by 3 degrees each frame
        degrees2 += 7 # rotate by 7 degrees each frame


def terminate():
    pygame.quit()
    sys.exit()

def showGameOverScreen():
    gameOverFont = pygame.font.Font('freesansbold.ttf', 150)
    gameSurf = gameOverFont.render('Game', True, WHITE)
    overSurf = gameOverFont.render('Over', True, WHITE)
    gameRect = gameSurf.get_rect()
    overRect = overSurf.get_rect()
    gameRect.midtop = (WINDOWWIDTH / 2, 10)
    overRect.midtop = (WINDOWWIDTH / 2, gameRect.height + 10 + 25)

    DISPLAYSURF.blit(gameSurf, gameRect)
    DISPLAYSURF.blit(overSurf, overRect)
    drawPressKeyMsg()
    pygame.display.update()
    pygame.time.wait(500)
#KRT 14/06/2012 rewrite event detection to deal with mouse use
    pygame.event.get()  #clear out event queue 
    while True:
        if checkForKeyPress():
            return
#KRT 12/06/2012 reduce processor loading in gameover screen.
        pygame.time.wait(100)


if __name__ == '__main__':
    main()
